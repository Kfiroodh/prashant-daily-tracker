PRASHANT — Daily Activity Tracker

कैसे चलाएं:
1. `index.html` को किसी ब्राउज़र में खोलें (डबल-क्लिक या ब्राउज़र में ड्रैग करके)।
2. तारीख चुनें, study session जोड़ें (विषय और घंटे), फोन और नींद के घंटे भरें, फिर "Save Entry" पर क्लिक करें।
3. Entries ब्राउज़ करने के लिए नीचे History देखें। डेटा आपके ब्राउज़र की `localStorage` में सुरक्षित रहता है।

नए फीचर अब शामिल हैं:
- Goal setting: आप Weekly study goal सेट कर सकते हैं और प्रोग्रेस देख सकते हैं।
- Analytics: Last 7 days और Last 30 days के लिए study-hours बार चार्ट जो summary में दिखता है।
 - Analytics: Last 7 days और Last 30 days के लिए study-hours बार चार्ट जो summary में दिखता है।
 - Subject-wise charts: किसी period (7 या 30 days) के लिए subject-wise breakdown (pie chart) भी summary में दिखता है।


अभी क्या कर सकते हैं:
- ब्राउज़र में `index.html` खोलें और entries जोड़ें।
- summary में `Weekly study goal` सेट करें और `Last 7 days`/`Last 30 days` बटन से analytics देखें।

आगे क्या जोड़ना चाहेंगे:
- CSV export/import
- Monthly aggregate report और subject-wise charts
- PWA/mobiles सुधार

बताइए मैं कौन-सा आगे जोड़ूँ।